print '[*] We\'re going to set things up for you!'
import os
basepath = os.getcwd()
print '[*] Copying console to /usr/bin... ',
os.system('cp ' + basepath + '/nbsconsole /usr/bin')
print '[DONE]'
print '[*] Copying update tool to /usr/bin... ',
os.system('cp -r ' + basepath + '/nbsupdate /usr/bin')
print '[DONE]'
print '[*] Copying configuration files to /usr/share... ',
os.system('cp -r ' + basepath + '/nbs /usr/share')
print '[DONE]'
print '[*] We\'re done setting up!'
print '[*] Enter "nbsconsole" to get started!'

